#version 120
varying vec2 vTexCoord;
uniform sampler2D skyTexture; // 큐브맵이 아닌 일반 2D 파노라마 텍스처!

void main() {
    gl_FragColor = texture2D(skyTexture, vTexCoord);
}