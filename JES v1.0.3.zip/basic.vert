#version 120

varying vec3 vNormal;
varying vec3 vWorldPos;
varying vec4 vFragPosLightSpace;

varying vec2 vTexCoord; 

uniform mat4 modelMatrix;       // 엔진에서 받아올 물체의 월드 행렬
uniform mat4 lightSpaceMatrix;  // 빛의 투영 행렬

void main() {
    // 1. 순수 월드 좌표 계산 (이게 있어야 가까이 가도 안 까매집니다)
    vec4 worldPos = modelMatrix * gl_Vertex;
    vWorldPos = worldPos.xyz;
    
    // 2. 노멀(법선)도 월드 기준으로 회전 적용
    vNormal = mat3(modelMatrix) * gl_Normal;
    
    // 3. 그림자 판단을 위한 빛 기준 좌표
    vFragPosLightSpace = lightSpaceMatrix * worldPos;
    
    // 4. 화면 출력용 좌표 (고정 파이프라인 행렬 사용)
    gl_Position = gl_ModelViewProjectionMatrix * gl_Vertex;

    vTexCoord = gl_MultiTexCoord0.xy; 
    
    gl_Position = gl_ModelViewProjectionMatrix * gl_Vertex;
}