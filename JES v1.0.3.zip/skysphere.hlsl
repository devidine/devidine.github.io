cbuffer ConstantBuffer : register(b0)
{
    matrix modelMatrix;
    matrix viewProjMatrix; // View projection without translation
    matrix lightSpaceMatrix;
    
    float3 objectColor;
    float intensity;
    
    float3 lightDir;
    int hasTexture;
    
    float3 lightColor;
    float cloudCover; 
    
    float3 viewPos;
    float timeOfDay;  
};

Texture2D skyTex : register(t0);
SamplerState samLinear : register(s0);

struct VS_INPUT
{
    float3 pos : POSITION;
    float3 normal : NORMAL;
    float2 texCoord : TEXCOORD;
};

struct PS_INPUT
{
    float4 pos : SV_POSITION;
    float3 worldPos : POSITION;
    float2 texCoord : TEXCOORD;
};

PS_INPUT VSMain(VS_INPUT input)
{
    PS_INPUT output = (PS_INPUT)0;
    
    float4 worldPosition = mul(modelMatrix, float4(input.pos, 1.0f));
    float4 clipPos = mul(viewProjMatrix, worldPosition);
    
    clipPos.z = clipPos.w; // 항상 뒤에 그려지도록 유도
    
    output.pos = clipPos;
    output.worldPos = worldPosition.xyz;
    output.texCoord = input.texCoord;
    
    return output;
}

// 간단한 노이즈 함수
float hash(float2 p) {
    p = frac(p * float2(123.34f, 456.21f));
    p += dot(p, p + 45.32f);
    return frac(p.x * p.y);
}

float noise(float2 x) {
    float2 i = floor(x);
    float2 f = frac(x);
    f = f * f * (3.0f - 2.0f * f);
    float a = hash(i + float2(0.0f, 0.0f));
    float b = hash(i + float2(1.0f, 0.0f));
    float c = hash(i + float2(0.0f, 1.0f));
    float d = hash(i + float2(1.0f, 1.0f));
    return lerp(lerp(a, b, f.x), lerp(c, d, f.x), f.y);
}

float fbm(float2 p) {
    float f = 0.0f;
    f += 0.5000f * noise(p); p = p * 2.02f;
    f += 0.2500f * noise(p); p = p * 2.03f;
    f += 0.1250f * noise(p); p = p * 2.01f;
    f += 0.0625f * noise(p);
    return f;
}

// 듀얼 로브(Dual Lobe) Henyey-Greenstein 위상 함수 (초현실적인 태양빛 흩어짐 계산)
float HG(float cosTheta, float gVal) {
    return (1.0f - gVal * gVal) / pow(abs(1.0f + gVal * gVal - 2.0f * gVal * cosTheta), 1.5f);
}

float4 PSMain(PS_INPUT input) : SV_TARGET
{
    // 하늘 모델을 위한 Ray 방향
    float3 viewDir = normalize(input.worldPos - viewPos);
    float3 lDir = normalize(-lightDir); // 빛이 향하는 방향 (태양이 있는 쪽)

    // 1. 대기 산란 분위기 그라데이션
    float sunDot = dot(viewDir, lDir);
    float sunHeight = max(0.0f, lDir.y); 
    float viewHeight = max(0.0f, viewDir.y); 

    float3 skyZenith = float3(0.15f, 0.35f, 0.8f);
    float3 skyHorizon = float3(0.5f, 0.7f, 0.9f);
    float3 sunsetColor = float3(1.0f, 0.4f, 0.1f);
    float3 nightColor = float3(0.02f, 0.02f, 0.05f);
    
    float t = smoothstep(0.0f, 1.0f, viewHeight);
    
    // 시간에 따른 색상 혼합 (수평선)
    float3 currentHorizon = lerp(sunsetColor, skyHorizon, smoothstep(0.0f, 0.2f, sunHeight));
    currentHorizon = lerp(nightColor, currentHorizon, smoothstep(-0.1f, 0.1f, sunHeight));
    
    // 시간에 따른 색상 혼합 (천정)
    float3 currentZenith = lerp(nightColor * 0.5f, skyZenith, smoothstep(-0.1f, 0.2f, sunHeight));
    
    // 하늘 베이스 색상
    float3 skyColor = lerp(currentHorizon, currentZenith, t);

    // 2. 태양 디스크
    float sunGlow = max(0.0f, sunDot);
    float halo = pow(sunGlow, 16.0f) * 0.5f;
    float sunDisc = pow(sunGlow, 2048.0f) * 2.0f;
    
    // 일몰 시간에 태양빛을 붉고 은은하게
    float3 sunColor = lerp(float3(1.0f, 0.3f, 0.0f), float3(1.0f, 1.0f, 0.9f), smoothstep(0.0f, 0.3f, sunHeight));
    
    skyColor += sunColor * halo;
    skyColor += sunColor * sunDisc;

// 3. 구름 레이어 (고해상도 다중 레이어 Volumetric Clouds)
    float cloudAlpha = 0.0f;
    float3 cloudColor = float3(0.0f, 0.0f, 0.0f);
    
    if (viewDir.y > 0.01f) {
        // [A] 2D 권운(Cirrus) 레이어 (높고 얇은 구름)
        float2 cirrusUV = viewDir.xz / max(viewDir.y, 0.01f) * 1.5f;
        cirrusUV.x += timeOfDay * 0.5f; // 아주 천천히 이동
        float cirrusNoise = fbm(cirrusUV * 0.5f) * 0.5f + fbm(cirrusUV * 1.2f) * 0.5f;
        float cirrusDensity = smoothstep(0.5f, 1.0f, cirrusNoise) * cloudCover * 0.6f;
        float3 cirrusColor = lerp(skyColor, sunColor, sunGlow * 0.8f);
        
        cloudColor += cirrusColor * cirrusDensity;
        cloudAlpha += cirrusDensity;
        
        // [B] 3D 적운(Cumulus) 레이어 (볼류메트릭 레이마칭)
        float3 rayStart = viewPos;
        float3 rayDir = viewDir;
        
        int steps = 50; 
        float stepSize = 1.0f; // 스텝 사이즈를 동적으로 늘려 매우 넓은 영역 커버
        float cloudScale = 0.012f; 
        float cloudSpeed = 0.2f; // 매우 천천히, 웅장하게
        
        float transmittance = 1.0f;
        float3 scatteredLight = float3(0,0,0);
        float tDist = 15.0f / max(viewDir.y, 0.1f); // 천정은 가깝게, 지평선은 멀리서 레이 시작
        
        float threshold = 1.0f - cloudCover; 
        
        float phaseForward = HG(sunDot, 0.65f); // 태양을 향한 매우 강렬한 은빛 테두리
        float phaseBack = HG(sunDot, -0.2f); // 뒷면 역광 산란
        float phaseBlend = lerp(1.0f, (phaseForward * 0.7f + phaseBack * 0.3f), 0.8f);

        for (int i = 0; i < steps; i++) {
            float3 p = rayStart + rayDir * tDist;
            
            p.x += timeOfDay * cloudSpeed * 10.0f;
            p.z += timeOfDay * cloudSpeed * 4.0f;
            
            // FBM 다단계 노이즈 구성 (솜털 같은 디테일)
            float3 basePos = p * cloudScale;
            float baseN = fbm(basePos.xz + basePos.y) * 0.6f + fbm(basePos.zx - basePos.y * 0.5f) * 0.4f;
            
            float3 detailPos1 = p * cloudScale * 3.5f; 
            float detailN1 = fbm(detailPos1.xz - timeOfDay * 2.0f) * 0.5f;
            
            float3 detailPos2 = p * cloudScale * 9.0f; // 마이크로 난기류
            float detailN2 = fbm(detailPos2.zx + timeOfDay * 4.0f) * 0.25f;
            
            float density = baseN - (detailN1 + detailN2) * 0.5f;
            
            // Spherical Horizon Mapping: 가상의 행성 곡률 적용. 
            // 거리가 멀어질수록 고도가 떨어져 지평선에 구름이 깔림.
            float trueAltitude = p.y + (p.x * p.x + p.z * p.z) / 10000.0f;
            
            float heightFraction = saturate((trueAltitude - 20.0f) / 45.0f);
            float heightShape = pow(4.0f * heightFraction * (1.0f - heightFraction), 0.7f);
            density *= heightShape;
            
            density = max(0.0f, density - threshold) * 3.5f; 
            
            if (density > 0.01f) {
                // 광원 방향 다중 샘플링 (빛이 구름 안을 투과하는 느낌 강화)
                float d1 = fbm((p + lDir * 2.0f) * cloudScale);
                float d2 = fbm((p + lDir * 5.0f) * cloudScale);
                float sunDensity = max(0.0f, d1 - threshold) * 2.0f + max(0.0f, d2 - threshold) * 1.5f;
                
                // Beer-Lambert 감쇠 및 파우더 효과 부스트
                float lightTransmittance = exp(-sunDensity * 3.0f);
                float powderEffect = 1.0f - exp(-sunDensity * 1.5f); 
                float totalSunLight = lightTransmittance * powderEffect * phaseBlend;
                
                float3 ambientCloud = lerp(float3(0.45f, 0.50f, 0.65f), nightColor, smoothstep(0.0f, -0.2f, sunHeight));
                float3 currentCloudLight = lerp(ambientCloud, sunColor * 2.0f, totalSunLight * max(0.0f, sunHeight + 0.1f));
                
                float dTrans = exp(-density * stepSize);
                scatteredLight += currentCloudLight * density * stepSize * transmittance;
                transmittance *= dTrans;
                
                if (transmittance < 0.01f) break; 
            }
            // 멀어질수록 스텝 크기를 선형/지수적으로 증가시켜 거대한 하늘 렌더링 최적화
            tDist += stepSize;
            stepSize *= 1.05f; 
        }
        
        float cumulusAlpha = 1.0f - transmittance;
        cloudColor = lerp(cloudColor, scatteredLight, cumulusAlpha);
        cloudAlpha = saturate(cloudAlpha + cumulusAlpha);
        
        // 먼 거리/지평선 페이드 아웃
        cloudAlpha *= smoothstep(0.01f, 0.15f, viewDir.y);
    }

    // 4. 별 생성 (밤하늘)
    float starIntensity = 0.0f;
    if (sunHeight < 0.1f && viewDir.y > 0.0f) {
        float2 starUV = viewDir.xy * 25.0f;
        float starNoise = hash(starUV);
        if (starNoise > 0.995f) {
            float twinkle = sin(timeOfDay * 150.0f + starNoise * 100.0f) * 0.5f + 0.5f;
            starIntensity = (starNoise - 0.995f) * 200.0f * twinkle;
            starIntensity *= smoothstep(0.1f, -0.1f, sunHeight); // 낮에는 안 보이게
            // 구름 뒤에는 안 보이게
            starIntensity *= (1.0f - cloudAlpha);
        }
    }
    
    skyColor += float3(1.0f, 1.0f, 1.0f) * starIntensity;

    // 구름 합성 (Volumetric 결과 합성)
    float3 finalColor = lerp(skyColor, skyColor + cloudColor, clamp(cloudAlpha, 0.0f, 1.0f));

    // ACES Tone Mapping Approximation (Exposure + HDR)
    float exposure = 1.0f;
    finalColor = finalColor * exposure;
    
    float a = 2.51f;
    float b = 0.03f;
    float c = 2.43f;
    float d = 0.59f;
    float e = 0.14f;
    finalColor = saturate((finalColor*(a*finalColor+b))/(finalColor*(c*finalColor+d)+e));
    
    // Gamma Correction
    finalColor = pow(finalColor, 1.0f / 2.2f); 

    return float4(finalColor, 1.0f);
}
