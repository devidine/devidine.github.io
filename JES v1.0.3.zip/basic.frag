#version 120

varying vec3 vNormal;
varying vec3 vWorldPos;
varying vec4 vFragPosLightSpace;
varying vec2 vTexCoord; // 👈 버텍스 셰이더에서 받아올 UV 좌표 추가

uniform vec3 lightDir;
uniform vec3 lightColor;
uniform float intensity;
uniform vec3 objectColor;
uniform vec3 viewPos;
uniform sampler2D shadowMap;

uniform sampler2D diffuseTex; // 👈 텍스처 이미지
uniform bool hasTexture;      // 👈 텍스처 유무 확인

float rand(vec2 co) {
    return fract(sin(dot(co.xy ,vec2(12.9898,78.233))) * 43758.5453);
}

float ShadowCalculation(vec4 fragPosLightSpace, vec3 normal, vec3 lightDir) {
    vec3 projCoords = fragPosLightSpace.xyz / fragPosLightSpace.w;
    projCoords = projCoords * 0.5 + 0.5;
    
    if(projCoords.z > 1.0) return 0.0;
    
    float currentDepth = projCoords.z;
    float bias = max(0.005 * (1.0 - dot(normal, lightDir)), 0.001);
    
    float shadow = 0.0;
    vec2 texelSize = vec2(1.0 / 4096.0); // 4096 해상도로 증가
    
    // Vogel Disk / Poisson Sampling for soft shadows (언리얼 같은 부드러운 그림자)
    float noise = rand(gl_FragCoord.xy) * 6.2831853; 
    int samples = 16;
    float spread = 3.5; // 그림자가 퍼지는 정도 (부드러움)
    
    for(int i = 0; i < 16; ++i) {
        float r = sqrt((float(i) + 0.5) / 16.0);
        float theta = float(i) * 2.3999632 + noise; // 2.3999632 = Golden angle
        vec2 offset = vec2(cos(theta), sin(theta)) * r * spread;
        
        float pcfDepth = texture2D(shadowMap, projCoords.xy + offset * texelSize).r; 
        shadow += currentDepth - bias > pcfDepth ? 1.0 : 0.0;        
    }
    shadow /= 16.0;
    
    return shadow;
}

void main() {
    // 👈 텍스처 색상 추출 (텍스처가 없으면 흰색)
    vec4 texColor = hasTexture ? texture2D(diffuseTex, vTexCoord) : vec4(1.0);

    vec3 norm = normalize(vNormal);
    vec3 lightDirCalc = normalize(-lightDir); 

    // 언리얼 느낌 (반구형 스카이 라이팅 - Hemispheric Ambient)
    vec3 skyColor = vec3(0.55, 0.70, 0.85); // 하늘 색
    vec3 groundColor = vec3(0.15, 0.15, 0.15); // 바닥 색
    float hemiMix = 0.5 * (norm.y + 1.0); // 위를 볼수록 하늘색, 아래를 볼수록 바닥색
    vec3 ambient = mix(groundColor, skyColor, hemiMix) * 0.6 * lightColor * intensity;

    float diff = max(dot(norm, lightDirCalc), 0.0);
    vec3 diffuse = diff * lightColor * intensity;

    vec3 viewDir = normalize(viewPos - vWorldPos);
    vec3 halfwayDir = normalize(lightDirCalc + viewDir);  
    float spec = pow(max(dot(norm, halfwayDir), 0.0), 48.0); // PBR 느낌의 날카로운 하이라이트로 상향
    vec3 specular = spec * lightColor * intensity * 0.6;

    float shadow = ShadowCalculation(vFragPosLightSpace, norm, lightDirCalc);       
    
    // 👈 최종 합성에 texColor 적용
    vec3 lighting = (ambient + (1.0 - shadow) * (diffuse + specular)) * objectColor * texColor.rgb;
    
    gl_FragColor = vec4(lighting, texColor.a);
}