cbuffer ConstantBuffer : register(b0)
{
    matrix modelMatrix;
    matrix viewProjMatrix;
}

struct VS_INPUT
{
    float3 pos : POSITION;
    float3 normal : NORMAL;
    float2 texCoord : TEXCOORD;
};

struct PS_INPUT
{
    float4 pos : SV_POSITION;
};

PS_INPUT VSMain(VS_INPUT input)
{
    PS_INPUT output = (PS_INPUT)0;
    float4 worldPosition = mul(modelMatrix, float4(input.pos, 1.0f));
    output.pos = mul(viewProjMatrix, worldPosition);
    return output;
}

float4 PSMain(PS_INPUT input) : SV_TARGET
{
    // 아무것도 반환하지 않음, 오직 Depth 버퍼만 기록함
    return float4(1.0f, 1.0f, 1.0f, 1.0f);
}
