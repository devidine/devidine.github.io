cbuffer ConstantBuffer : register(b0)
{
    matrix modelMatrix;
    matrix viewProjMatrix;
    matrix lightSpaceMatrix;
    
    float3 objectColor;
    float intensity;
    
    float3 lightDir;
    int hasTexture;
    
    float3 lightColor;
    float cloudCover; 
    
    float3 viewPos;
    float timeOfDay;  

    int isWater;
    float waveIntensity;
    float waveSpeed;
    float waveTime;
    
    float3 playerPos;
    float playerRippleEnergy;
    
    float2 screenSize;
    float2 padding2;
};

// Texture & Sampler
Texture2D diffuseTex : register(t0);
SamplerState samLinear : register(s0);

// Shadow Map
Texture2D shadowMap : register(t1);
SamplerComparisonState samShadow : register(s1);

// Normal Map
Texture2D normalMapTex : register(t2);

// Scene Depth for Water
Texture2D sceneDepthTex : register(t3);

struct VS_INPUT
{
    float3 pos : POSITION;
    float3 normal : NORMAL;
    float2 texCoord : TEXCOORD;
};

struct PS_INPUT
{
    float4 pos : SV_POSITION;
    float3 worldPos : POSITION;
    float3 normal : NORMAL;
    float2 texCoord : TEXCOORD;
    float4 fragPosLightSpace : TEXCOORD1;
};

// ----------------------------------------------------
// Vertex Shader
// ----------------------------------------------------
PS_INPUT VSMain(VS_INPUT input)
{
    PS_INPUT output = (PS_INPUT)0;
    
    float4 worldPosition = mul(modelMatrix, float4(input.pos, 1.0f));
    
    // 물결과 ริ플 파생 및 정점 버텍스 이동 효과 (isWater=1 시)
    if (isWater == 1 && input.pos.y >= 0.0f) { // 상단 표면 부분만 이동
        // 사실적인 5개의 Gerstner Waves
        float k = 2.0f; 
        float w = waveSpeed * 1.5f;
        float a = waveIntensity * 0.05f;
        
        float2 d1 = normalize(float2(1.0f, 0.8f));
        float2 d2 = normalize(float2(0.4f, -0.7f));
        float2 d3 = normalize(float2(-0.8f, 0.2f));
        float2 d4 = normalize(float2(-0.3f, 0.9f));
        float2 d5 = normalize(float2(0.8f, -0.4f));
        
        float3 p = worldPosition.xyz;
        float t = waveTime;
        
        float f1 = dot(d1, p.xz) * k - t * w;
        float f2 = dot(d2, p.xz) * k * 1.4f - t * w * 1.2f;
        float f3 = dot(d3, p.xz) * k * 2.1f - t * w * 0.9f;
        float f4 = dot(d4, p.xz) * k * 3.0f - t * w * 1.5f;
        float f5 = dot(d5, p.xz) * k * 4.5f - t * w * 2.0f;
        
        p.x += d1.x * (a * cos(f1)) + d2.x * (a * 0.6f * cos(f2)) + d3.x * (a * 0.4f * cos(f3)) + d4.x * (a * 0.2f * cos(f4)) + d5.x * (a * 0.1f * cos(f5));
        p.z += d1.y * (a * cos(f1)) + d2.y * (a * 0.6f * cos(f2)) + d3.y * (a * 0.4f * cos(f3)) + d4.y * (a * 0.2f * cos(f4)) + d5.y * (a * 0.1f * cos(f5));
        p.y += a * sin(f1) + a * 0.6f * sin(f2) + a * 0.4f * sin(f3) + a * 0.2f * sin(f4) + a * 0.1f * sin(f5);
        
        worldPosition.xyz = p;
        
        // 플레이어 접촉면으로부터 생기는 Ripple 방사 파동
        if (playerRippleEnergy > 0.01f) {
            float dist = distance(worldPosition.xz, playerPos.xz);
            float ripple = sin((dist - waveTime * 8.0f) * 10.0f) * exp(-dist * 0.8f);
            worldPosition.y += ripple * playerRippleEnergy;
        }
    }
    
    output.worldPos = worldPosition.xyz;
    
    output.normal = mul((float3x3)modelMatrix, input.normal);
    output.texCoord = input.texCoord;
    
    output.pos = mul(viewProjMatrix, worldPosition);
    output.fragPosLightSpace = mul(lightSpaceMatrix, worldPosition);
    
    return output;
}

// ----------------------------------------------------
// Pixel Shader
// ----------------------------------------------------

float LinearizeDepth(float z_ndc) {
    return -0.10001f / (z_ndc - 1.0001f);
}

// 진일보된 PCF 그림자 필터링 (부드러운 언리얼스타일)
float ShadowCalculation(float4 fragPosLightSpace, float3 normal, float3 lightDirCalc)
{
    float3 projCoords = fragPosLightSpace.xyz / fragPosLightSpace.w;
    
    projCoords.x = projCoords.x * 0.5f + 0.5f;
    projCoords.y = -projCoords.y * 0.5f + 0.5f;

    if (projCoords.z > 1.0f || projCoords.x < 0.0f || projCoords.x > 1.0f || projCoords.y < 0.0f || projCoords.y > 1.0f)
        return 0.0f;

    float currentDepth = projCoords.z;
    float bias = max(0.005f * (1.0f - dot(normal, lightDirCalc)), 0.001f);
    
    // 5x5 PCF로 해상도를 높임 (언리얼스러운 부드러운 외곽선)
    float shadow = 0.0f;
    float2 texelSize = 1.0f / 4096.0f; 
    
    // 퀄리티 최적를 위해 Poisson Disk이나 3x3 범위 내 16 샘플링 등 여러 방식이 있으나 
    // 여기서는 넓은 5x5 반경을 사용하여 소프트 섀도우를 연출
    for(int x = -2; x <= 2; ++x)
    {
        for(int y = -2; y <= 2; ++y)
        {
            float pcfDepth = shadowMap.SampleCmpLevelZero(samShadow, projCoords.xy + float2(x, y) * texelSize, currentDepth - bias);
            shadow += pcfDepth;
        }
    }
    shadow /= 25.0f;
    
    return 1.0f - shadow;
}

// ACES Tone Mapping Approximation
float3 ACESToneMapping(float3 color)
{
    float a = 2.51f;
    float b = 0.03f;
    float c = 2.43f;
    float d = 0.59f;
    float e = 0.14f;
    return saturate((color*(a*color+b))/(color*(c*color+d)+e));
}

float4 PSMain(PS_INPUT input) : SV_TARGET
{
    float4 texColor = float4(1.0f, 1.0f, 1.0f, 1.0f);
    if (hasTexture == 1)
    {
        texColor = diffuseTex.Sample(samLinear, input.texCoord);
        // sRGB to Linear
        texColor.rgb = pow(texColor.rgb, 2.2f);
    }
    
    float3 albedo = objectColor * texColor.rgb;
    float3 norm = normalize(input.normal);
    
    // ==========================================
    // 0. 깊이 처리 및 물 특수 효과
    // ==========================================
    float depthDiff = 10.0f; // 기본 깊이 (깊은 바다)
    float foamFactor = 0.0f;

    if (isWater == 1) {
        float2 screenUV = input.pos.xy / screenSize;
        float zBackgroundNDC = sceneDepthTex.Sample(samLinear, screenUV).r;
        float zWaterNDC = input.pos.z;
        
        float zBackground = LinearizeDepth(zBackgroundNDC);
        float zWater = LinearizeDepth(zWaterNDC);
        depthDiff = max(0.0f, zBackground - zWater);
        
        // 얕은 곳 해안선 거품 (Foam) - 깊이가 1.2m 미만일 때 흰색 거품 생성
        foamFactor = saturate(1.0f - depthDiff / 1.2f); 
        // 파도 봉우리에도 거품 약간 추가
        foamFactor += pow(saturate(input.worldPos.y * 0.8f), 2.0f) * 0.3f;
        
        // 두 개의 엇갈린 방향으로 노멀 애니메이션 레이어 스크롤 적용
        float2 animatedUV1 = input.texCoord * 4.0f + float2(waveTime * 0.05f, waveTime * 0.03f);
        float2 animatedUV2 = input.texCoord * 6.0f + float2(waveTime * -0.04f, waveTime * 0.05f);
        
        float3 normal1 = normalMapTex.Sample(samLinear, animatedUV1).rgb;
        float3 normal2 = normalMapTex.Sample(samLinear, animatedUV2).rgb;
        
        float3 normalSample = normalize(normal1 + normal2 - 1.0f);
        
        if (length(normal1) > 0.01f) {
            float3 T = normalize(cross(float3(0,0,1), norm));
            float3 B = normalize(cross(norm, T));
            float3x3 TBN = float3x3(T, B, norm);
            norm = normalize(mul(normalSample, TBN));
        }
    }
    
    float3 lDir = normalize(-lightDir); 

    // ==========================================
    // 1. 역동적 환경광 (시간과 위치 반영)
    // ==========================================
    float sunHeight = max(0.0f, lDir.y);
    float3 skyColor = lerp(float3(0.02f, 0.02f, 0.05f), float3(0.5f, 0.7f, 1.0f), smoothstep(-0.2f, 0.3f, sunHeight));
    
    // 일몰 시 보라/노을빛
    skyColor = lerp(skyColor, float3(0.8f, 0.4f, 0.2f), smoothstep(0.0f, 0.2f, sunHeight) * (1.0f - smoothstep(0.2f, 0.5f, sunHeight)));
    
    float3 groundColor = float3(0.1f, 0.1f, 0.1f);
    float hemiMix = 0.5f * (norm.y + 1.0f);
    
    // 하늘색과 바닥색을 섞어 사실적인 앰비언트 라이트를 적용
    float3 ambient = lerp(groundColor, skyColor, hemiMix) * 0.5f;

    // ==========================================
    // 2. Diffuse & Specular (PBR 스타일 근사)
    // ==========================================
    float diff = max(dot(norm, lDir), 0.0f);
    // 디퓨즈에 빛의 강도와 색상을 곱해줍니다
    float3 diffuse = diff * lightColor * intensity;

    float3 viewDir = normalize(viewPos - input.worldPos);
    float3 halfwayDir = normalize(lDir + viewDir);
    float spec = pow(max(dot(norm, halfwayDir), 0.0f), isWater == 1 ? 512.0f : 32.0f); // 물은 아주 강렬한 반광
    float3 specular = spec * lightColor * intensity * (isWater == 1 ? 4.0f : 0.5f);

    if (isWater == 1) {
        // (1) 사용자가 UI에서 지정한 objectColor를 반영하여 동적인 물 색상 산출
        float3 baseColor = objectColor;
        // 완전한 검정색(물 기본값)인 경우 기존 에메랄드 시안색으로 fallback
        if (length(baseColor) < 0.05f) {
            baseColor = float3(0.05f, 0.4f, 0.5f);
        }
        
        // 큐브의 색상을 그대로 사용
        float3 shallowWaterColor = lerp(baseColor, float3(1.0f, 1.0f, 1.0f), 0.15f);
        float3 deepOceanColor = baseColor * 0.4f;
        
        float localDepthFactor = saturate(depthDiff / 6.0f);
        albedo = lerp(shallowWaterColor, deepOceanColor, localDepthFactor);
        
        // (2) Fresnel 효과 (물 표면 각도에 따른 하늘색 반사)
        float f0 = 0.03f;
        float cosTheta = max(dot(norm, viewDir), 0.0f);
        float fresnel = f0 + (1.0f - f0) * pow(1.0f - cosTheta, 5.0f);
        
        // 하늘색 계산
        float3 skyReflect = lerp(float3(0.05f, 0.05f, 0.15f), float3(0.5f, 0.7f, 1.0f), smoothstep(-0.2f, 0.3f, sunHeight));
        skyReflect = lerp(skyReflect, float3(0.8f, 0.4f, 0.2f), smoothstep(0.0f, 0.2f, sunHeight) * (1.0f - smoothstep(0.2f, 0.5f, sunHeight)));
        
        albedo = lerp(albedo, skyReflect, fresnel * 0.25f); // 하늘색 반사율 축소
        
        // (3) 거품(Foam) 합성
        float3 foamColor = float3(0.9f, 0.95f, 1.0f);
        albedo = lerp(albedo, foamColor, pow(foamFactor, 2.5f) * 0.6f); // 폼의 세기 축소
    }

    // ==========================================
    // 3. 그림자 적용 및 최종 조합
    // ==========================================
    float shadow = ShadowCalculation(input.fragPosLightSpace, norm, lDir);

    // 밤에는 빛이 약하므로 자연스럽게 그림자 깊이를 낮춤
    float shadowStrength = lerp(0.2f, 1.0f, smoothstep(0.0f, 0.2f, sunHeight));
    float finalShadow = lerp(1.0f, 1.0f - shadow, shadowStrength);
    
    // 앰비언트 베이스에 그림자 적용된 디튜즈 및 스펙큘러 라이팅을 더함 
    // 앰비언트 베이스에 그림자 적용된 디튜즈 및 스펙큘러 라이팅을 더함 
    float3 lighting = ambient * albedo + finalShadow * (diffuse * albedo + specular);

    // ==========================================
    // 4. HDR 노출 보정 및 ACES 톤매핑
    // ==========================================
    float exposure = 1.25f; // 너무 밝게 타지않게 조절
    lighting = lighting * exposure;
    lighting = ACESToneMapping(lighting);
    
    // 5. Gamma 보정 (Linear to sRGB)
    lighting = pow(lighting, 1.0f / 2.2f);

    return float4(lighting, texColor.a);
}
