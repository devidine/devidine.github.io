#version 120
varying vec2 vTexCoord;

void main() {
    // 구(Sphere)를 만들 때 입력한 UV 좌표를 그대로 넘겨줍니다.
    vTexCoord = gl_MultiTexCoord0.xy;
    
    vec4 pos = gl_ModelViewProjectionMatrix * gl_Vertex;
    // [마법의 코드] z값을 최대치(w)로 만들어서 항상 모든 물체 뒤(배경)에 그려지게 합니다.
    gl_Position = pos.xyww; 
}